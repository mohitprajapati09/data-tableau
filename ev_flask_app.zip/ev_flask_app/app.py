"""EV Market Dashboard - Flask app built from the EV_Project_Updated_Data Tableau workbook."""
from pathlib import Path

import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request

BASE = Path(__file__).parent
DATA = BASE / "data"

app = Flask(__name__)


def load_data() -> pd.DataFrame:
    frames = []
    for name, label in (("ev_market_train.csv", "train"), ("ev_market_test.csv", "test")):
        df = pd.read_csv(DATA / name)
        df["dataset"] = label
        frames.append(df)
    df = pd.concat(frames, ignore_index=True)
    for c in ("manufacturer", "manufacturing_country", "market_region", "category",
              "battery_type", "drivetrain", "recommended_use_case"):
        df[c] = df[c].astype("category")
    df["sales_co2"] = df["co2_saved_tons_per_year"] * df["annual_sales_units"].fillna(0)
    return df


DF = load_data()

FILTERS = {
    "region": "market_region",
    "category": "category",
    "battery": "battery_type",
    "country": "manufacturing_country",
    "use_case": "recommended_use_case",
}


def apply_filters(df: pd.DataFrame) -> pd.DataFrame:
    for arg, col in FILTERS.items():
        val = request.args.get(arg)
        if val and val != "All":
            df = df[df[col] == val]
    year = request.args.get("year")
    if year and year != "All":
        df = df[df["model_year"] == int(year)]
    return df


def clean(x):
    """JSON-safe rounding."""
    if isinstance(x, (np.floating, float)):
        return None if np.isnan(x) else round(float(x), 2)
    if isinstance(x, (np.integer,)):
        return int(x)
    return x


def pack(series: pd.Series, top=None, ascending=False):
    s = series.sort_values(ascending=ascending)
    if top:
        s = s.head(top)
    return {"labels": [str(i) for i in s.index], "values": [clean(v) for v in s.values]}


@app.route("/")
def dashboard():
    return render_template("dashboard.html", options=filter_options(), active="dashboard")


@app.route("/explorer")
def explorer():
    return render_template("explorer.html", options=filter_options(), active="explorer")


@app.route("/insights")
def insights():
    return render_template("insights.html", active="insights")


def filter_options():
    return {
        "region": sorted(DF["market_region"].unique()),
        "category": sorted(DF["category"].unique()),
        "battery": sorted(DF["battery_type"].unique()),
        "country": sorted(DF["manufacturing_country"].unique()),
        "year": sorted(int(y) for y in DF["model_year"].unique()),
    }


@app.route("/api/dashboard")
def api_dashboard():
    d = apply_filters(DF)
    if d.empty:
        return jsonify({"empty": True})

    kpis = {
        "records": int(len(d)),
        "total_sales": clean(d["annual_sales_units"].sum()),
        "avg_price": clean(d["price_usd"].mean()),
        "avg_range": clean(d["range_km"].mean()),
        "avg_co2": clean(d["co2_saved_tons_per_year"].mean()),
        "total_co2": clean(d["sales_co2"].sum()),
        "avg_rating": clean(d["customer_rating"].mean()),
    }

    obs = dict(observed=True)
    trend = d.groupby("model_year", **obs)["annual_sales_units"].sum().sort_index()
    by_region = d.groupby("market_region", **obs)["annual_sales_units"].sum()
    by_country = d.groupby("manufacturing_country", **obs)["annual_sales_units"].sum()
    by_cat = d.groupby("category", **obs)["annual_sales_units"].sum()
    mfr = d.groupby("manufacturer", **obs).agg(
        sales=("annual_sales_units", "sum"),
        price=("price_usd", "mean"),
        rating=("customer_rating", "mean"),
        rng=("range_km", "mean"),
    ).sort_values("sales", ascending=False).head(15)

    battery = d.groupby("battery_type", **obs).agg(
        range_km=("range_km", "mean"),
        cycle_life=("battery_cycle_life", "mean"),
        degradation=("battery_degradation_pct_5yr", "mean"),
        efficiency=("efficiency_wh_per_km", "median"),
        count=("vehicle_id", "count"),
    )

    # range distribution histogram
    bins = list(range(0, 700, 50))
    cuts = pd.cut(d["range_km"], bins=bins, right=False)
    hist = cuts.value_counts(sort=False)
    range_hist = {"labels": [f"{int(i.left)}-{int(i.right)}" for i in hist.index],
                  "values": [int(v) for v in hist.values]}

    # charging vs efficiency scatter (sampled)
    sc = d[["max_dc_charging_kw", "efficiency_wh_per_km", "category"]].dropna()
    sc = sc[sc["efficiency_wh_per_km"] < 600]
    sc = sc.sample(min(900, len(sc)), random_state=7)
    scatter = [{"x": clean(a), "y": clean(b)} for a, b in zip(sc["max_dc_charging_kw"], sc["efficiency_wh_per_km"])]

    resale = d.groupby("category", **obs)["resale_value_pct_3yr"].mean()

    region_co2 = d.groupby("market_region", **obs).agg(
        co2_per_vehicle=("co2_saved_tons_per_year", "mean"),
        total_co2=("sales_co2", "sum"),
        sales=("annual_sales_units", "sum"),
    ).sort_values("total_co2", ascending=False)

    return jsonify({
        "empty": False,
        "kpis": kpis,
        "trend": pack(trend, ascending=True) | {"labels": [str(i) for i in trend.index]},
        "region": pack(by_region),
        "country": pack(by_country),
        "category": pack(by_cat),
        "manufacturers": {
            "labels": list(mfr.index.astype(str)),
            "sales": [clean(v) for v in mfr["sales"]],
            "price": [clean(v) for v in mfr["price"]],
            "rating": [clean(v) for v in mfr["rating"]],
            "range": [clean(v) for v in mfr["rng"]],
        },
        "battery": {
            "labels": list(battery.index.astype(str)),
            "range": [clean(v) for v in battery["range_km"]],
            "cycle_life": [clean(v) for v in battery["cycle_life"]],
            "degradation": [clean(v) for v in battery["degradation"]],
            "efficiency": [clean(v) for v in battery["efficiency"]],
            "count": [clean(v) for v in battery["count"]],
        },
        "range_hist": range_hist,
        "scatter": scatter,
        "resale": pack(resale),
        "region_co2": {
            "labels": list(region_co2.index.astype(str)),
            "co2_per_vehicle": [clean(v) for v in region_co2["co2_per_vehicle"]],
            "total_co2": [clean(v) for v in region_co2["total_co2"]],
            "sales": [clean(v) for v in region_co2["sales"]],
        },
    })


TABLE_COLS = ["vehicle_id", "model_name", "manufacturer", "model_year", "manufacturing_country",
              "market_region", "category", "battery_type", "battery_capacity_kwh", "range_km",
              "price_usd", "acceleration_0_100_sec", "top_speed_kmph", "max_dc_charging_kw",
              "safety_rating_stars", "customer_rating", "annual_sales_units"]


@app.route("/api/vehicles")
def api_vehicles():
    d = apply_filters(DF)
    q = (request.args.get("q") or "").strip().lower()
    if q:
        mask = (d["model_name"].str.lower().str.contains(q, na=False)
                | d["manufacturer"].astype(str).str.lower().str.contains(q, na=False)
                | d["vehicle_id"].str.lower().str.contains(q, na=False))
        d = d[mask]

    sort = request.args.get("sort", "price_usd")
    if sort not in TABLE_COLS:
        sort = "price_usd"
    asc = request.args.get("dir", "desc") == "asc"
    d = d.sort_values(sort, ascending=asc, na_position="last")

    page = max(1, int(request.args.get("page", 1)))
    per = min(100, max(10, int(request.args.get("per", 25))))
    total = len(d)
    chunk = d.iloc[(page - 1) * per: page * per][TABLE_COLS]
    rows = [{k: clean(v) if not isinstance(v, str) else v for k, v in r.items()}
            for r in chunk.astype(object).where(chunk.notna(), None).to_dict("records")]
    rows = [{k: (str(v) if k in ("manufacturer", "manufacturing_country", "market_region", "category", "battery_type") else v)
             for k, v in r.items()} for r in rows]
    return jsonify({"total": total, "page": page, "per": per, "pages": max(1, -(-total // per)),
                    "columns": TABLE_COLS, "rows": rows})


@app.route("/api/insights")
def api_insights():
    d = DF
    best_cat_resale = d.groupby("category", observed=True)["resale_value_pct_3yr"].mean().idxmax()
    top_region = d.groupby("market_region", observed=True)["annual_sales_units"].sum().idxmax()
    top_cat = d.groupby("category", observed=True)["annual_sales_units"].sum().idxmax()
    top_batt = d.groupby("battery_type", observed=True)["range_km"].mean().idxmax()
    low_deg = d.groupby("battery_type", observed=True)["battery_degradation_pct_5yr"].mean().idxmin()
    corr = d[["price_usd", "range_km", "battery_capacity_kwh", "motor_power_kw", "top_speed_kmph",
              "acceleration_0_100_sec", "customer_rating", "safety_rating_stars",
              "resale_value_pct_3yr", "efficiency_wh_per_km"]].corr().round(2)
    return jsonify({
        "headline": [
            {"label": "Top-selling region", "value": str(top_region)},
            {"label": "Top-selling category", "value": str(top_cat)},
            {"label": "Longest-range battery type (avg)", "value": str(top_batt)},
            {"label": "Lowest 5-yr degradation", "value": str(low_deg)},
            {"label": "Best 3-yr resale category", "value": str(best_cat_resale)},
        ],
        "corr": {"labels": list(corr.columns), "matrix": corr.values.tolist()},
        "records": int(len(d)),
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
