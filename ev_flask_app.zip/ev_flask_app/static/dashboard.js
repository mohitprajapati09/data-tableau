const PALETTE = ['#0f9d77','#1c6fd1','#f59e0b','#e5484d','#8b5cf6','#06b6d4','#ec4899','#84cc16','#f97316','#64748b','#14b8a6','#a855f7','#eab308','#3b82f6','#ef4444'];
const charts = {};
const fmt = new Intl.NumberFormat('en-US', {notation:'compact', maximumFractionDigits:1});
const money = n => '$' + Math.round(n).toLocaleString('en-US');
const ids = ['region','category','battery','country','year'];

function params(){
  const p = new URLSearchParams();
  ids.forEach(i => { const v = document.getElementById('f-'+i).value; if(v !== 'All') p.set(i, v); });
  return p;
}

function draw(id, config){
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(document.getElementById(id), config);
}
const base = (extra={}) => ({responsive:true, maintainAspectRatio:true, plugins:{legend:{display:false}}, ...extra});
const yFmt = {ticks:{callback:v => fmt.format(v)}};

async function load(){
  const r = await fetch('/api/dashboard?' + params());
  const d = await r.json();
  document.getElementById('empty').hidden = !d.empty;
  if (d.empty) return;

  const k = d.kpis;
  document.getElementById('k-sales').textContent = fmt.format(k.total_sales);
  document.getElementById('k-price').textContent = money(k.avg_price);
  document.getElementById('k-range').textContent = Math.round(k.avg_range) + ' km';
  document.getElementById('k-co2').textContent = k.avg_co2.toFixed(2) + ' t';
  document.getElementById('k-rating').textContent = k.avg_rating.toFixed(2) + ' ★';

  draw('c-trend', {type:'line', data:{labels:d.trend.labels, datasets:[{label:'Units sold', data:d.trend.values, borderColor:PALETTE[0], backgroundColor:'rgba(15,157,119,.15)', fill:true, tension:.3, pointRadius:4}]}, options:base({scales:{y:yFmt}})});
  draw('c-region', {type:'bar', data:{labels:d.region.labels, datasets:[{data:d.region.values, backgroundColor:PALETTE}]}, options:base({scales:{y:yFmt}})});
  draw('c-country', {type:'bar', data:{labels:d.country.labels, datasets:[{data:d.country.values, backgroundColor:PALETTE[1]}]}, options:base({scales:{y:yFmt}})});
  draw('c-category', {type:'bar', data:{labels:d.category.labels, datasets:[{data:d.category.values, backgroundColor:PALETTE[2]}]}, options:base({scales:{y:yFmt}})});
  draw('c-mfr', {type:'bar', data:{labels:d.manufacturers.labels, datasets:[{data:d.manufacturers.sales, backgroundColor:PALETTE[4]}]}, options:base({indexAxis:'y', scales:{x:yFmt}})});
  draw('c-batt-range', {type:'bar', data:{labels:d.battery.labels, datasets:[{data:d.battery.range, backgroundColor:PALETTE}]}, options:base()});
  draw('c-batt-life', {type:'bar', data:{labels:d.battery.labels, datasets:[
      {label:'Avg cycle life', data:d.battery.cycle_life, backgroundColor:PALETTE[1], yAxisID:'y'},
      {label:'5-yr degradation %', data:d.battery.degradation, backgroundColor:PALETTE[3], yAxisID:'y1'}]},
    options:{responsive:true, plugins:{legend:{display:true}}, scales:{y:{position:'left'}, y1:{position:'right', grid:{drawOnChartArea:false}}}}});
  draw('c-hist', {type:'bar', data:{labels:d.range_hist.labels, datasets:[{label:'Vehicles', data:d.range_hist.values, backgroundColor:PALETTE[5]}]}, options:base({scales:{y:yFmt}})});
  draw('c-scatter', {type:'scatter', data:{datasets:[{data:d.scatter, backgroundColor:'rgba(28,111,209,.45)', pointRadius:3}]},
    options:base({scales:{x:{title:{display:true,text:'Max DC charging (kW)'}}, y:{title:{display:true,text:'Efficiency (Wh/km)'}}}})});
  draw('c-resale', {type:'bar', data:{labels:d.resale.labels, datasets:[{data:d.resale.values, backgroundColor:PALETTE[7]}]}, options:base({scales:{y:{min:0}}})});

  const tb = document.querySelector('#t-co2 tbody');
  tb.innerHTML = d.region_co2.labels.map((l,i) =>
    `<tr><td>${l}</td><td>${fmt.format(d.region_co2.sales[i])}</td><td>${d.region_co2.co2_per_vehicle[i].toFixed(2)}</td><td>${fmt.format(d.region_co2.total_co2[i])}</td></tr>`).join('');
}

ids.forEach(i => document.getElementById('f-'+i).addEventListener('change', load));
document.getElementById('reset').addEventListener('click', () => { ids.forEach(i => document.getElementById('f-'+i).value='All'); load(); });
load();
