const ids = ['region','category','battery','country','year'];
let page = 1, sort = 'price_usd', dir = 'desc', pages = 1, timer;
const labels = {vehicle_id:'ID',model_name:'Model',manufacturer:'Manufacturer',model_year:'Year',manufacturing_country:'Country',market_region:'Region',category:'Category',battery_type:'Battery',battery_capacity_kwh:'kWh',range_km:'Range km',price_usd:'Price',acceleration_0_100_sec:'0-100s',top_speed_kmph:'Top km/h',max_dc_charging_kw:'DC kW',safety_rating_stars:'Safety',customer_rating:'Rating',annual_sales_units:'Sales'};

function params(){
  const p = new URLSearchParams({page, sort, dir});
  ids.forEach(i => { const v = document.getElementById('f-'+i).value; if(v !== 'All') p.set(i, v); });
  const q = document.getElementById('q').value.trim(); if(q) p.set('q', q);
  return p;
}
function cell(k, v){
  if (v === null || v === undefined) return '–';
  if (k === 'price_usd') return '$' + Math.round(v).toLocaleString('en-US');
  if (k === 'annual_sales_units') return Math.round(v).toLocaleString('en-US');
  return v;
}
async function load(){
  const d = await (await fetch('/api/vehicles?' + params())).json();
  pages = d.pages;
  document.querySelector('#grid thead').innerHTML = '<tr>' + d.columns.map(c =>
    `<th data-c="${c}">${labels[c]||c}${c===sort?(dir==='asc'?' ▲':' ▼'):''}</th>`).join('') + '</tr>';
  document.querySelector('#grid tbody').innerHTML = d.rows.map(r =>
    '<tr>' + d.columns.map(c => `<td>${cell(c, r[c])}</td>`).join('') + '</tr>').join('');
  document.getElementById('count').textContent = d.total.toLocaleString('en-US') + ' vehicles';
  document.getElementById('pageinfo').textContent = `Page ${d.page} of ${d.pages.toLocaleString('en-US')}`;
  document.getElementById('prev').disabled = d.page <= 1;
  document.getElementById('next').disabled = d.page >= d.pages;
  document.querySelectorAll('#grid th').forEach(th => th.onclick = () => {
    const c = th.dataset.c; dir = (sort === c && dir === 'desc') ? 'asc' : 'desc'; sort = c; page = 1; load();
  });
}
ids.forEach(i => document.getElementById('f-'+i).addEventListener('change', () => { page = 1; load(); }));
document.getElementById('q').addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => { page = 1; load(); }, 300); });
document.getElementById('prev').onclick = () => { if(page > 1){ page--; load(); } };
document.getElementById('next').onclick = () => { if(page < pages){ page++; load(); } };
document.getElementById('reset').onclick = () => { ids.forEach(i => document.getElementById('f-'+i).value='All'); document.getElementById('q').value=''; page=1; load(); };
load();
