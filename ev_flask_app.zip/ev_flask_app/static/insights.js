(async () => {
  const d = await (await fetch('/api/insights')).json();
  document.getElementById('headline').innerHTML = d.headline.map(h =>
    `<div class="kpi"><span>${h.label}</span><strong style="font-size:18px">${h.value}</strong></div>`).join('');
  const L = d.corr.labels, n = L.length, el = document.getElementById('corr');
  el.style.gridTemplateColumns = `150px repeat(${n}, minmax(54px,1fr))`;
  let html = '<div></div>' + L.map(l => `<div class="lab" style="justify-content:center">${l.replace(/_/g,' ')}</div>`).join('');
  d.corr.matrix.forEach((row, i) => {
    html += `<div class="lab">${L[i].replace(/_/g,' ')}</div>`;
    row.forEach(v => {
      const a = Math.min(1, Math.abs(v));
      const bg = v >= 0 ? `rgba(15,157,119,${0.12 + a*0.85})` : `rgba(229,72,77,${0.12 + a*0.85})`;
      html += `<div class="cell" style="background:${bg}" title="${v}">${v.toFixed(2)}</div>`;
    });
  });
  el.innerHTML = html;
})();
