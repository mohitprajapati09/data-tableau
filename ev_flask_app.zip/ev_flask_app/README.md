# EV Market Intelligence – Flask app

Rebuilt from the Tableau workbook `EV_Project_Updated_Data.twbx` (train + test CSVs = 300,000 vehicles).

## Run
```bash
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 (first start takes ~3 s to load the CSVs).

## Pages
- `/` Dashboard – KPIs + 11 charts mirroring the Tableau sheets (sales trend, region, country, category,
  manufacturers, battery tech, range distribution, charging vs efficiency, 3-yr retained value, regional CO₂),
  all driven by Region / Category / Battery / Country / Year filters.
- `/explorer` – searchable, sortable, paginated table of all vehicles.
- `/insights` – headline findings and a correlation heatmap.

## Layout
`app.py` (routes + pandas aggregation) · `templates/` · `static/` (CSS + Chart.js scripts) · `data/` (CSVs)
Charts load Chart.js from a CDN, so the browser needs internet access.
