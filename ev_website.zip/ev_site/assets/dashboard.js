const D = window.EVDATA, L = D.lists, M = D.mets;
const PALETTE = ['#0f9d77','#1c6fd1','#f59e0b','#e5484d','#8b5cf6','#06b6d4','#ec4899','#84cc16','#f97316','#64748b'];
const fmt = new Intl.NumberFormat('en-US',{notation:'compact',maximumFractionDigits:1});
const money = n => '$'+Math.round(n).toLocaleString('en-US');
const charts = {}, mi = Object.fromEntries(M.map((m,i)=>[m,i+5]));
const F = {region:['market_region',0], category:['category',1], battery:['battery_type',2], country:['manufacturing_country',3], year:['model_year',4]};

Object.entries(F).forEach(([id,[dim]])=>{
  document.getElementById('f-'+id).innerHTML = '<option>All</option>'+L[dim].map(v=>`<option>${v}</option>`).join('');
  document.getElementById('f-'+id).addEventListener('change', render);
});
document.getElementById('reset').onclick = ()=>{ Object.keys(F).forEach(i=>document.getElementById('f-'+i).value='All'); render(); };

function sel(){ const s={}; for(const [id,[dim,pos]] of Object.entries(F)){ const v=document.getElementById('f-'+id).value; if(v!=='All') s[pos]=L[dim].map(String).indexOf(v); } return s; }
const ok = (r,s)=>{ for(const p in s) if(r[p]!==s[p]) return false; return true; };
const draw=(id,cfg)=>{ if(charts[id]) charts[id].destroy(); charts[id]=new Chart(document.getElementById(id),cfg); };
const base=(x={})=>({responsive:true,plugins:{legend:{display:false}},...x});
const yF={ticks:{callback:v=>fmt.format(v)}};
const group=(rows,pos,key)=>{ const o={}; rows.forEach(r=>{ o[r[pos]]=(o[r[pos]]||0)+r[mi[key]]; }); return o; };
const ratio=(rows,pos,s,n)=>{ const a={},b={}; rows.forEach(r=>{a[r[pos]]=(a[r[pos]]||0)+r[mi[s]]; b[r[pos]]=(b[r[pos]]||0)+r[mi[n]];}); const o={}; for(const k in a) o[k]=b[k]?a[k]/b[k]:0; return o; };
const lab=(dim,o,sort)=>{ let e=Object.entries(o); if(sort) e.sort((a,b)=>b[1]-a[1]); return {labels:e.map(([k])=>L[dim][k]), values:e.map(([,v])=>v)}; };

function render(){
  const s=sel(), rows=D.rows.filter(r=>ok(r,s));
  document.getElementById('empty').hidden = rows.length>0;
  if(!rows.length) return;
  const sum=k=>rows.reduce((a,r)=>a+r[mi[k]],0);
  document.getElementById('k-sales').textContent=fmt.format(sum('sales'));
  document.getElementById('k-price').textContent=money(sum('price_usd_s')/sum('price_usd_n'));
  document.getElementById('k-range').textContent=Math.round(sum('range_km_s')/sum('range_km_n'))+' km';
  document.getElementById('k-co2').textContent=(sum('co2_saved_tons_per_year_s')/sum('co2_saved_tons_per_year_n')).toFixed(2)+' t';
  document.getElementById('k-rating').textContent=(sum('customer_rating_s')/sum('customer_rating_n')).toFixed(2)+' ★';

  const t=lab('model_year',group(rows,4,'sales')); t.labels=t.labels.map(String);
  const tt=Object.entries(group(rows,4,'sales')).sort((a,b)=>a[0]-b[0]);
  draw('c-trend',{type:'line',data:{labels:tt.map(([k])=>L.model_year[k]),datasets:[{data:tt.map(([,v])=>v),borderColor:PALETTE[0],backgroundColor:'rgba(15,157,119,.15)',fill:true,tension:.3,pointRadius:4}]},options:base({scales:{y:yF}})});
  const r1=lab('market_region',group(rows,0,'sales'),1); draw('c-region',{type:'bar',data:{labels:r1.labels,datasets:[{data:r1.values,backgroundColor:PALETTE}]},options:base({scales:{y:yF}})});
  const r2=lab('manufacturing_country',group(rows,3,'sales'),1); draw('c-country',{type:'bar',data:{labels:r2.labels,datasets:[{data:r2.values,backgroundColor:PALETTE[1]}]},options:base({scales:{y:yF}})});
  const r3=lab('category',group(rows,1,'sales'),1); draw('c-category',{type:'bar',data:{labels:r3.labels,datasets:[{data:r3.values,backgroundColor:PALETTE[2]}]},options:base({scales:{y:yF}})});
  const mf=D.manufacturers; draw('c-mfr',{type:'bar',data:{labels:mf.labels,datasets:[{data:mf.sales,backgroundColor:PALETTE[4]}]},options:base({indexAxis:'y',scales:{x:yF}})});

  const br=lab('battery_type',ratio(rows,2,'range_km_s','range_km_n')), bc=lab('battery_type',ratio(rows,2,'battery_cycle_life_s','battery_cycle_life_n')), bd=lab('battery_type',ratio(rows,2,'battery_degradation_pct_5yr_s','battery_degradation_pct_5yr_n'));
  draw('c-batt-range',{type:'bar',data:{labels:br.labels,datasets:[{data:br.values,backgroundColor:PALETTE}]},options:base()});
  draw('c-batt-life',{type:'bar',data:{labels:bc.labels,datasets:[{label:'Avg cycle life',data:bc.values,backgroundColor:PALETTE[1],yAxisID:'y'},{label:'5-yr degradation %',data:bd.values,backgroundColor:PALETTE[3],yAxisID:'y1'}]},options:{responsive:true,plugins:{legend:{display:true}},scales:{y:{position:'left'},y1:{position:'right',grid:{drawOnChartArea:false}}}}});

  const hs={}; for(const p in s) if(p>3) delete s[p];
  const hc=new Array(D.bins.length-1).fill(0);
  D.hist.forEach(h=>{ if((s[0]===undefined||h[0]===s[0])&&(s[1]===undefined||h[1]===s[1])&&(s[2]===undefined||h[2]===s[2])&&(sel()[4]===undefined||h[3]===sel()[4])) hc[h[4]]+=h[5]; });
  draw('c-hist',{type:'bar',data:{labels:D.bins.slice(0,-1).map((b,i)=>b+'-'+D.bins[i+1]),datasets:[{data:hc,backgroundColor:PALETTE[5]}]},options:base({scales:{y:yF}})});
  draw('c-scatter',{type:'scatter',data:{datasets:[{data:D.scatter.map(([x,y])=>({x,y})),backgroundColor:'rgba(28,111,209,.45)',pointRadius:3}]},options:base({scales:{x:{title:{display:true,text:'Max DC charging (kW)'}},y:{title:{display:true,text:'Efficiency (Wh/km)'}}}})});
  const rs=lab('category',ratio(rows,1,'resale_value_pct_3yr_s','resale_value_pct_3yr_n'),1); draw('c-resale',{type:'bar',data:{labels:rs.labels,datasets:[{data:rs.values,backgroundColor:PALETTE[7]}]},options:base({scales:{y:{min:0}}})});

  const sa=group(rows,0,'sales'), co=group(rows,0,'sco2'), cs=group(rows,0,'co2_saved_tons_per_year_s'), cn=group(rows,0,'co2_saved_tons_per_year_n');
  document.querySelector('#t-co2 tbody').innerHTML=Object.keys(co).sort((a,b)=>co[b]-co[a]).map(k=>`<tr><td>${L.market_region[k]}</td><td>${fmt.format(sa[k])}</td><td>${(cs[k]/cn[k]).toFixed(2)}</td><td>${fmt.format(co[k])}</td></tr>`).join('');
}
render();
