const D=window.EVDATA, cols=D.cols, ix=Object.fromEntries(cols.map((c,i)=>[c,i]));
const labels={vehicle_id:'ID',model_name:'Model',manufacturer:'Manufacturer',model_year:'Year',manufacturing_country:'Country',market_region:'Region',category:'Category',battery_type:'Battery',range_km:'Range km',price_usd:'Price',acceleration_0_100_sec:'0-100s',top_speed_kmph:'Top km/h',safety_rating_stars:'Safety',customer_rating:'Rating',annual_sales_units:'Sales'};
const F={region:'market_region',category:'category',battery:'battery_type',country:'manufacturing_country',year:'model_year'};
let page=1,sort='price_usd',dir=-1,per=25,rows=[];
Object.entries(F).forEach(([id,col])=>{
  const el=document.getElementById('f-'+id); el.innerHTML='<option>All</option>'+D.lists[col].map(v=>`<option>${v}</option>`).join('');
  el.onchange=()=>{page=1;render();};
});
document.getElementById('q').oninput=()=>{page=1;render();};
document.getElementById('reset').onclick=()=>{Object.keys(F).forEach(i=>document.getElementById('f-'+i).value='All');document.getElementById('q').value='';page=1;render();};
document.getElementById('prev').onclick=()=>{if(page>1){page--;render();}};
document.getElementById('next').onclick=()=>{page++;render();};
const cell=(c,v)=>v==null?'–':c==='price_usd'?'$'+Math.round(v).toLocaleString('en-US'):c==='annual_sales_units'?Math.round(v).toLocaleString('en-US'):v;
function render(){
  const q=document.getElementById('q').value.trim().toLowerCase();
  rows=D.sample.filter(r=>{
    for(const [id,col] of Object.entries(F)){const v=document.getElementById('f-'+id).value; if(v!=='All'&&String(r[ix[col]])!==v) return false;}
    return !q||[r[ix.model_name],r[ix.manufacturer],r[ix.vehicle_id]].some(x=>String(x).toLowerCase().includes(q));
  });
  const k=ix[sort]; rows.sort((a,b)=>{const x=a[k],y=b[k]; if(x==null) return 1; if(y==null) return -1; return (x>y?1:x<y?-1:0)*dir;});
  const pages=Math.max(1,Math.ceil(rows.length/per)); if(page>pages) page=pages;
  document.querySelector('#grid thead').innerHTML='<tr>'+cols.map(c=>`<th data-c="${c}">${labels[c]||c}${c===sort?(dir>0?' ▲':' ▼'):''}</th>`).join('')+'</tr>';
  document.querySelector('#grid tbody').innerHTML=rows.slice((page-1)*per,page*per).map(r=>'<tr>'+cols.map((c,i)=>`<td>${cell(c,r[i])}</td>`).join('')+'</tr>').join('');
  document.getElementById('count').textContent=rows.length.toLocaleString('en-US')+' vehicles';
  document.getElementById('pageinfo').textContent=`Page ${page} of ${pages}`;
  document.getElementById('prev').disabled=page<=1; document.getElementById('next').disabled=page>=pages;
  document.querySelectorAll('#grid th').forEach(th=>th.onclick=()=>{const c=th.dataset.c; dir=(sort===c&&dir<0)?1:-1; sort=c; page=1; render();});
}
render();
