const D=window.EVDATA,I=D.insights;
const h=[['Top-selling region',I.top_region],['Top-selling category',I.top_cat],['Longest-range battery type (avg)',I.long_batt],['Lowest 5-yr degradation',I.low_deg],['Best 3-yr resale category',I.resale_cat]];
document.getElementById('headline').innerHTML=h.map(([l,v])=>`<div class="kpi"><span>${l}</span><strong style="font-size:18px">${v}</strong></div>`).join('');
const L=D.corr.labels,el=document.getElementById('corr');
el.style.gridTemplateColumns=`150px repeat(${L.length}, minmax(54px,1fr))`;
let html='<div></div>'+L.map(l=>`<div class="lab" style="justify-content:center">${l.replace(/_/g,' ')}</div>`).join('');
D.corr.m.forEach((row,i)=>{html+=`<div class="lab">${L[i].replace(/_/g,' ')}</div>`;row.forEach(v=>{const a=Math.min(1,Math.abs(v));html+=`<div class="cell" style="background:${v>=0?`rgba(15,157,119,${.12+a*.85})`:`rgba(229,72,77,${.12+a*.85})`}" title="${v}">${v.toFixed(2)}</div>`;});});
el.innerHTML=html;
