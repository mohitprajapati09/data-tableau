EV Market Intelligence - static website
Open index.html in any browser (double-click). No server or Python needed.
Pages: index.html (dashboard), explorer.html (data explorer), insights.html.
Charts use Chart.js from a CDN, so an internet connection is required.
To host it, upload the whole folder to any static host (GitHub Pages, Netlify, etc.).
